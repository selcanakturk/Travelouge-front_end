import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:geocoding/geocoding.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:travelouge_frontend/features/route/screens/add_route_screen.dart';
import 'package:travelouge_frontend/features/route/screens/route_detail_screen.dart';
import 'package:intl/intl.dart';

Dio dio = Dio();

class TripsScreen extends StatefulWidget {
  const TripsScreen({super.key});

  @override
  State<TripsScreen> createState() => _TripsScreenState();
}

class _TripsScreenState extends State<TripsScreen> {
  List<Map<String, dynamic>> userRoutes = [];
  final String defaultImage = 'assets/png/default.png';

  @override
  void initState() {
    super.initState();
    fetchUserRoutes();
  }

  String formatDate(dynamic rawDate) {
    try {
      if (rawDate == null || rawDate.toString().isEmpty) return "Tarih yok";

      final dateTime = DateTime.tryParse(rawDate.toString());
      if (dateTime == null) return "Tarih yok";

      final localDate = dateTime.toLocal(); // 🔁 UTC -> yerel saat dilimi
      final formatter = DateFormat('d MMMM y', 'tr_TR'); // örn: 16 Nisan 2025
      return formatter.format(localDate);
    } catch (e) {
      print("📅 Tarih formatlama hatası: $e");
      return "Tarih yok";
    }
  }

  Future<void> fetchUserRoutes() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('access_token');
    const baseUrl = 'http://127.0.0.1:8000';

    try {
      final response = await dio.get(
        '$baseUrl/api/routes/',
        options: Options(headers: {'Authorization': 'Bearer $token'}),
      );

      List<dynamic> data = response.data;

      // Asenkron şekilde her rota için konum çözümle
      List<Map<String, dynamic>> routes = [];
      for (var route in data) {
        if (route["is_deleted"] == true)
          continue; // silinmiş rotaları dahil etme

        String imageUrl = defaultImage;
        if (route["images"] != null &&
            route["images"].isNotEmpty &&
            route["images"][0]["image"] != null) {
          imageUrl = "$baseUrl${route["images"][0]["image"]}";
        }

        String location =
            await _getLocationFromCoordinates(route["coordinates"]);

        route["image"] = imageUrl;
        route["location"] = location;
        route["date"] = route["created_at"];
        route["user"] = route["user"] ?? route["user_id"] ?? route["owner"];

        routes.add(route);
      }
      setState(() {
        userRoutes = routes;
      });
    } catch (e) {
      print("❌ Hata oluştu: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title:
            const Text("Seyahatlerim", style: TextStyle(color: Colors.white)),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pushNamedAndRemoveUntil(
              context, '/home', (route) => false),
        ),
      ),
      body: userRoutes.isEmpty
          ? _buildEmptyState()
          : GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 0.8,
              ),
              itemCount: userRoutes.length,
              itemBuilder: (context, index) {
                return _buildRouteCard(userRoutes[index]);
              },
            ),
      floatingActionButton: _buildFloatingButton(),
    );
  }

  Widget _buildFloatingButton() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0, right: 12.0),
      child: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddRouteScreen()),
          );
          fetchUserRoutes();
        },
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text("Yeni Rota",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.purple,
        elevation: 10,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.explore, size: 80, color: Colors.white24),
          const SizedBox(height: 16),
          const Text("Henüz bir rota eklemediniz!",
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white)),
          const SizedBox(height: 8),
          const Text("Yeni bir keşif yapmaya ne dersiniz?",
              style: TextStyle(fontSize: 16, color: Colors.white60)),
        ],
      ),
    );
  }

  Widget _buildRouteCard(Map<String, dynamic> route) {
    final String imageUrl = route["image"].toString();
    final bool isNetwork = imageUrl.startsWith("http");

    return GestureDetector(
      onTap: () async {
        final result = await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => RouteDetailPage(route: route),
          ),
        );

// ✅ Eğer rota silindiyse yeniden fetch et
        if (result == true) {
          fetchUserRoutes();
        }
      },
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          children: [
            Hero(
              tag: imageUrl + route["title"],
              child: isNetwork
                  ? Image.network(
                      imageUrl,
                      height: double.infinity,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) =>
                          Image.asset(defaultImage, fit: BoxFit.cover),
                    )
                  : Image.asset(
                      defaultImage,
                      height: double.infinity,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.black.withOpacity(0.6), Colors.transparent],
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Align(
                alignment: Alignment.bottomLeft,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      route["title"],
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        const Icon(Icons.location_on,
                            color: Colors.white70, size: 14),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            route["location"],
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 13),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        const Icon(Icons.calendar_today,
                            color: Colors.white70, size: 13),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            formatDate(route["date"]),
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 13),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

Future<String> _getLocationFromCoordinates(dynamic coords) async {
  try {
    if (coords == null || coords.isEmpty) return "Konum belirtilmedi";
    final lat = coords[0]["latitude"];
    final lng = coords[0]["longitude"];

    final placemarks = await placemarkFromCoordinates(lat, lng);
    if (placemarks.isNotEmpty) {
      final place = placemarks.first;
      return place.locality ??
          place.administrativeArea ??
          place.country ??
          "Bilinmeyen Konum";
    } else {
      return "Konum bulunamadı";
    }
  } catch (e) {
    print("📍 Konum çözümleme hatası: $e");
    return "Konum bulunamadı";
  }
}
