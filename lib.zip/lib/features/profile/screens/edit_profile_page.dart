import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:dio/dio.dart';

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _bioController = TextEditingController();

  bool _isLoading = false;
  File? _profileImage;
  String? _profileImageUrl;

  final String baseUrl = "http://192.168.2.45:8000"; // ✅ SENİN IP ADRESİN

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    _firstNameController.text = prefs.getString("first_name") ?? "";
    _lastNameController.text = prefs.getString("last_name") ?? "";
    _usernameController.text = prefs.getString("username") ?? "";
    _emailController.text = prefs.getString("email") ?? "";
    _bioController.text = prefs.getString("bio") ?? "";
    _profileImageUrl = prefs.getString("profile_picture");
    setState(() {});
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _profileImage = File(pickedFile.path);
      });
    }
  }

  Future<void> _updateProfile() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('access_token');
    final dio = Dio();

    final formData = FormData.fromMap({
      "first_name": _firstNameController.text,
      "last_name": _lastNameController.text,
      "username": _usernameController.text,
      "email": _emailController.text,
      "bio": _bioController.text,
      if (_profileImage != null)
        "profile_picture": await MultipartFile.fromFile(_profileImage!.path),
    });

    try {
      final response = await dio.put(
        "$baseUrl/api/profile/",
        data: formData,
        options: Options(headers: {
          "Authorization": "Bearer $token",
        }),
      );
      print("✅ SERVER RESPONSE: ${response.data}");

      if (response.statusCode == 200) {
        await prefs.setString("first_name", _firstNameController.text);
        await prefs.setString("last_name", _lastNameController.text);
        await prefs.setString("username", _usernameController.text);
        await prefs.setString("email", _emailController.text);
        await prefs.setString("bio", _bioController.text);

        final imageUrl = response.data["profile_picture"];
        if (imageUrl != null && imageUrl.toString().isNotEmpty) {
          final cleanUrl =
              imageUrl.startsWith("http") ? imageUrl : "$baseUrl$imageUrl";

          // BURADA timestamp EKLEMİYORUZ — sadece temiz URL!
          await prefs.setString("profile_picture", cleanUrl);

          setState(() {
            _profileImage = null;
            _profileImageUrl = cleanUrl;
          });
        }

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Profil başarıyla güncellendi.")),
          );
          Navigator.pop(context, true);
        }
      } else {
        throw Exception("Güncelleme hatası");
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Profil güncellenemedi.")),
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("Profili Düzenle",
            style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                GestureDetector(
                  onTap: _pickImage,
                  child: CircleAvatar(
                    radius: 50,
                    backgroundImage: _profileImage != null
                        ? FileImage(_profileImage!)
                        : (_profileImageUrl != null &&
                                _profileImageUrl!.startsWith("http"))
                            ? NetworkImage(_profileImageUrl!)
                            : const AssetImage("assets/png/default_profile.png")
                                as ImageProvider,
                  ),
                ),
                const SizedBox(height: 20),
                _buildTextField("Ad", _firstNameController),
                const SizedBox(height: 16),
                _buildTextField("Soyad", _lastNameController),
                const SizedBox(height: 16),
                _buildTextField("Kullanıcı Adı", _usernameController),
                const SizedBox(height: 16),
                _buildTextField("E-posta", _emailController),
                const SizedBox(height: 16),
                _buildTextField("Açıklama", _bioController, maxLines: 3),
                const SizedBox(height: 30),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _updateProfile,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.purple,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    child: _isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : const Text("Kaydet",
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            )),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller,
      {int maxLines = 1}) {
    return TextFormField(
      controller: controller,
      style: const TextStyle(color: Colors.white),
      maxLines: maxLines,
      validator: (value) =>
          value == null || value.isEmpty ? "Bu alan zorunludur" : null,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white70),
        filled: true,
        fillColor: Colors.white.withOpacity(0.1),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}
